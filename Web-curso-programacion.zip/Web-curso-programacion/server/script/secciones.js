document.addEventListener('DOMContentLoaded', () => {
        const seccionHTML = document.querySelector('.secciones');
        
})