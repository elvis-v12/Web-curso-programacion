export class Contenido {
        constructor(title, duracion, temas) {
                this.title = title;
                this.duracion = duracion;
                this.temas = temas;
        }
}
export class Temas {
        constructor(name, duracion) {
                this.name = name;
                this.duracion = duracion;
        }
}