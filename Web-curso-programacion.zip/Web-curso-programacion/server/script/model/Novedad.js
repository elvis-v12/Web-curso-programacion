export class Novedad {
        constructor(id, portada, name, description, date) {
                this.id = id;
                this.portada = portada;
                this.name = name;
                this.description = description;
                this.date = date;
        }
}