export class Curso {
        constructor(id, author, name, score, stars, votes, price, pricePrevous, matriculados, lastUpdate, language, description, shortDescription, requisitos, habilidades, detalles, ventajas, sesiones) {
                this.id = id;
                this.author = author;
                this.name = name;
                this.score = score;
                this.stars = stars;
                this.votes = votes;
                this.price = price;
                this.pricePrevous = pricePrevous;
                this.matriculados = matriculados;
                this.lastUpdate = lastUpdate;
                this.language = language;
                this.shortDescription = shortDescription;
                this.description = description;
                this.requisitos = requisitos;
                this.habilidades = habilidades;
                this.detalles = detalles;
                this.ventajas = ventajas;
                this.sesiones = sesiones;
        }
}
