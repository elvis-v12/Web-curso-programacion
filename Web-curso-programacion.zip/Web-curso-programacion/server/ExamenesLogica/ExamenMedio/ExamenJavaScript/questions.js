let questions = [
  {
    numb: 1,
    question:
      "¿Qué palabra clave usamos para declarar una variable en JavaScript?",
    answer: "let",
    options: ["var", "let", "const", "variable"],
  },
  {
    numb: 2,
    question:
      "¿Qué operador usamos para verificar si dos valores son exactamente iguales en JavaScript?",
    answer: "===",
    options: ["==", "=", "===", "!=="],
  },
  {
    numb: 3,
    question:
      "¿Cómo podemos escribir un comentario de una sola línea en JavaScript?",
    answer: "//",
    options: ["<!--", "#", "//", "/*"],
  },
  {
    numb: 4,
    question: "¿Cuál de los siguientes es un tipo de dato en JavaScript?",
    answer: "boolean",
    options: ["integer", "boolean", "character", "float"],
  },
];
