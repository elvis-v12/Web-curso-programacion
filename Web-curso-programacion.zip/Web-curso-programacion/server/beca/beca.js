document.getElementById('applyButton').addEventListener('click', function() {
    document.getElementById('applyModal').style.display = 'block'; // Muestra el modal
});

document.getElementById('closeModal').addEventListener('click', function() {
    document.getElementById('applyModal').style.display = 'none'; // Oculta el modal
});
