// Respuestas predefinidas basadas en palabras clave
const respuestas = {
    "hola": "¡Hola! ¿Cómo estás?",
    "adios": "¡Adiós! Espero verte pronto.",
    "nombre": "Soy un chatbot sin IA, creado para ayudarte.",
    "default": "Lo siento, no entiendo tu pregunta."
};

function sendMessage() {
    const input = document.getElementById('user-input').value.toLowerCase();
    const chatBox = document.getElementById('chat-box');

    // Añadir el mensaje del usuario al chat
    const userMessage = document.createElement('div');
    userMessage.classList.add('message', 'user-message');
    userMessage.textContent = input;
    chatBox.appendChild(userMessage);

    // Procesar la respuesta del bot
    let botResponse = respuestas["default"];
    for (let key in respuestas) {
        if (input.includes(key)) {
            botResponse = respuestas[key];
            break;
        }
    }

    // Añadir la respuesta del bot al chat
    const botMessage = document.createElement('div');
    botMessage.classList.add('message', 'bot-message');
    botMessage.textContent = botResponse;
    chatBox.appendChild(botMessage);

    // Limpiar el campo de entrada
    document.getElementById('user-input').value = '';

    // Mantener el scroll abajo
    chatBox.scrollTop = chatBox.scrollHeight;
}
